package com.mny.popularmovie.interfac;

import com.mny.popularmovie.bean.Movies;

public interface RlvItemClickListener {
    void onItemClickListener(Movies movies);
}
