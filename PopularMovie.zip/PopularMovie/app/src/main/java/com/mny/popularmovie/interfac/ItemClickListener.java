package com.mny.popularmovie.interfac;

public interface ItemClickListener {
    void onClick(String playMovie);
}
