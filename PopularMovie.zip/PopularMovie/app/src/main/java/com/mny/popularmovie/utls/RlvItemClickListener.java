package com.mny.popularmovie.utls;

import com.mny.popularmovie.bean.Movies;

public interface RlvItemClickListener {
    void onItemClickListener(Movies movies);
}
